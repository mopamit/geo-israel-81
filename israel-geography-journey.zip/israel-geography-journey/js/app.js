/* ------------------------------------------------------------------
   app.js — מסך הפתיחה.
------------------------------------------------------------------ */
(function () {
  'use strict';

  var nameInput   = document.getElementById('nameInput');
  var nameError   = document.getElementById('nameError');
  var startBtn    = document.getElementById('startBtn');
  var continueBtn = document.getElementById('continueBtn');
  var resetBtn    = document.getElementById('resetBtn');
  var savedNote   = document.getElementById('savedNote');

  IGJ.accessibility.init();

  if (!IGJ.storage.available()) {
    IGJ.nav.toast('הדפדפן חוסם שמירה מקומית. ההתקדמות לא תישמר בין ביקורים.');
  }

  var state = IGJ.storage.getState();
  var settings = IGJ.storage.getSettings();
  var hasJourney = IGJ.storage.hasJourney();

  if (state.studentName) nameInput.value = state.studentName;

  if (hasJourney) {
    continueBtn.hidden = false;
    resetBtn.hidden = false;
    startBtn.textContent = 'התחלת מסע חדש';

    var next = IGJ.progress.nextStation(state, settings);
    var overall = IGJ.progress.overall(state);
    savedNote.hidden = false;
    savedNote.textContent = next
      ? 'נשמרה התקדמות: ' + overall + '% מהמסע. התחנה הבאה — ' + next.title + '.'
      : 'כל התחנות הושלמו. אפשר לחזור ולתרגל.';
  }

  function cleanName(value) {
    return value.replace(/\s+/g, ' ').trim().slice(0, 30);
  }

  startBtn.addEventListener('click', function () {
    var name = cleanName(nameInput.value);
    if (!name) {
      nameError.hidden = false;
      nameInput.focus();
      return;
    }
    nameError.hidden = true;

    IGJ.storage.update(function (s) {
      s.studentName = name;
      if (!s.currentStation) s.currentStation = IGJ.stations[0].id;
    });
    IGJ.nav.toRoute();
  });

  nameInput.addEventListener('input', function () {
    if (nameInput.value.trim()) nameError.hidden = true;
  });

  nameInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') startBtn.click();
  });

  continueBtn.addEventListener('click', function () {
    IGJ.nav.toRoute();
  });

  resetBtn.addEventListener('click', function () {
    var sure = window.confirm('לאפס את כל ההתקדמות במכשיר הזה? הפעולה אינה הפיכה.');
    if (!sure) return;
    IGJ.storage.resetState();
    window.location.reload();
  });
})();
