/* ------------------------------------------------------------------
   route.js — מסך המסלול: שרטוט הקו, נקודות הציון וכרטיס התחנה.
------------------------------------------------------------------ */
(function () {
  'use strict';

  var routeEl   = document.getElementById('route');
  var svgEl     = document.getElementById('routeLine');
  var sheetEl   = document.getElementById('stationSheet');
  var nameEl    = document.getElementById('studentName');
  var meterEl   = document.getElementById('overallMeter');
  var meterText = document.getElementById('overallText');
  var lastFocus = null;

  var STATUS_TEXT = {
    'locked':      'נעולה',
    'available':   'זמינה',
    'in-progress': 'בתהליך',
    'completed':   'הושלמה'
  };

  /* ---------- שרטוט קו המסע ---------- */
  function drawLine(state, settings) {
    // המרה: x נמדד מימין, ה-SVG נמדד משמאל.
    var pts = IGJ.stations.map(function (s) {
      return { x: 100 - s.x, y: s.y, id: s.id };
    });

    function pathFrom(list) {
      if (list.length < 2) return '';
      var d = 'M ' + list[0].x + ' ' + list[0].y;
      for (var i = 1; i < list.length; i++) {
        var prev = list[i - 1], cur = list[i];
        var mx = (prev.x + cur.x) / 2;
        d += ' C ' + mx + ' ' + prev.y + ', ' + mx + ' ' + cur.y + ', ' + cur.x + ' ' + cur.y;
      }
      return d;
    }

    // כמה תחנות רצופות הושלמו — עד שם הקו מלא
    var done = 0;
    for (var i = 0; i < IGJ.stations.length; i++) {
      if (state.completedStations.indexOf(IGJ.stations[i].id) === -1) break;
      done++;
    }

    svgEl.innerHTML =
      '<path class="route__path" vector-effect="non-scaling-stroke" d="' + pathFrom(pts) + '"></path>' +
      (done > 1
        ? '<path class="route__path route__path--done" vector-effect="non-scaling-stroke" d="' +
          pathFrom(pts.slice(0, done)) + '"></path>'
        : '');
  }

  /* ---------- נקודות ציון ---------- */
  function glyphFor(status, index) {
    if (status === 'completed') return '✓';
    if (status === 'locked')    return '🔒';
    return String(index + 1);
  }

  function renderStations(state, settings) {
    routeEl.querySelectorAll('.station').forEach(function (n) { n.remove(); });

    IGJ.stations.forEach(function (station, index) {
      var status  = IGJ.progress.stateOf(station.id, state, settings);
      var percent = IGJ.progress.percentOf(station.id, state);
      var score   = IGJ.progress.scoreOf(station.id, state);

      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'station station--' + status;
      btn.style.setProperty('--station-color', station.color);
      btn.style.setProperty('--station-percent', percent + '%');
      btn.style.insetInlineEnd = station.x + '%';
      btn.style.insetBlockStart = station.y + '%';
      btn.dataset.station = station.id;

      var statusText = STATUS_TEXT[status];
      if (status === 'in-progress') statusText += ' · ' + percent + '%';
      if (status === 'completed' && score !== null && settings.showScores) {
        statusText += ' · ' + score + '%';
      }

      btn.innerHTML =
        '<span class="station__mark" aria-hidden="true">' +
          '<span class="station__glyph">' + glyphFor(status, index) + '</span>' +
        '</span>' +
        '<span class="station__text">' +
          '<span class="station__label">' + station.title + '</span>' +
          '<span class="station__status">' + statusText + '</span>' +
        '</span>';

      btn.setAttribute('aria-label',
        'תחנה ' + (index + 1) + ': ' + station.title + '. ' + statusText + '.');

      routeEl.appendChild(btn);
    });
  }

  /* ---------- כרטיס התחנה ---------- */
  function openSheet(station, status, state, settings) {
    var percent = IGJ.progress.percentOf(station.id, state);
    var locked  = status === 'locked';

    sheetEl.querySelector('.sheet__card').style.setProperty('--station-color', station.color);
    sheetEl.querySelector('#sheetTitle').textContent = station.title;
    sheetEl.querySelector('#sheetSubtitle').textContent = station.subtitle;
    sheetEl.querySelector('#sheetGoal').textContent = station.goal;
    sheetEl.querySelector('#sheetSteps').textContent = station.steps;
    sheetEl.querySelector('#sheetTime').textContent = station.minutes + ' דק׳';
    sheetEl.querySelector('#sheetState').textContent =
      locked ? 'נעולה' : (percent > 0 ? percent + '%' : STATUS_TEXT[status]);

    var enter = sheetEl.querySelector('#sheetEnter');
    if (locked) {
      enter.disabled = true;
      enter.textContent = 'יש להשלים תחילה את התחנה הקודמת';
    } else {
      enter.disabled = false;
      enter.textContent = (status === 'in-progress') ? 'המשך מהמקום שבו עצרתי'
                        : (status === 'completed')   ? 'חזרה לתרגול'
                        : 'כניסה לתחנה';
      enter.onclick = function () { IGJ.nav.toStation(station); };
    }

    lastFocus = document.activeElement;
    sheetEl.hidden = false;
    (locked ? sheetEl.querySelector('#sheetClose') : enter).focus();
  }

  function closeSheet() {
    sheetEl.hidden = true;
    if (lastFocus) lastFocus.focus();
  }

  /* ---------- ציור מחדש ---------- */
  function render() {
    var state = IGJ.storage.getState();
    var settings = IGJ.storage.getSettings();

    nameEl.textContent = state.studentName ? 'המסע של ' + state.studentName : '';

    var overall = IGJ.progress.overall(state);
    meterEl.style.width = overall + '%';
    meterEl.parentElement.setAttribute('aria-valuenow', String(overall));
    meterText.textContent = overall + '% מהמסע הושלמו';

    drawLine(state, settings);
    renderStations(state, settings);
  }

  /* ---------- אירועים ---------- */
  routeEl.addEventListener('click', function (e) {
    var btn = e.target.closest('.station');
    if (!btn) return;

    var state = IGJ.storage.getState();
    var settings = IGJ.storage.getSettings();
    var station = IGJ.stationById(btn.dataset.station);
    var status = IGJ.progress.stateOf(station.id, state, settings);

    openSheet(station, status, state, settings);
  });

  sheetEl.addEventListener('click', function (e) {
    if (e.target === sheetEl || e.target.closest('#sheetClose')) closeSheet();
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !sheetEl.hidden) closeSheet();
  });

  /* ---------- הפעלה ---------- */
  IGJ.accessibility.init();

  if (!IGJ.storage.available()) {
    IGJ.nav.toast('הדפדפן חוסם שמירה מקומית. ההתקדמות לא תישמר.');
  }

  render();
})();
