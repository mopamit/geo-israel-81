/* ------------------------------------------------------------------
   storage.js — שכבת השמירה היחידה באפליקציה.
   שום קובץ אחר לא ניגש ל-localStorage ישירות.
------------------------------------------------------------------ */
window.IGJ = window.IGJ || {};

(function () {
  'use strict';

  var STATE_KEY    = 'igj.state.v1';
  var SETTINGS_KEY = 'igj.settings.v1';
  var A11Y_KEY     = 'igj.a11y.v1';

  function emptyState() {
    return {
      studentName: '',
      currentStation: '',
      completedStations: [],
      stationProgress: {},   // { rivers: 3 }  — שלב אחרון שהושלם
      scores: {},            // { rivers: 85 }
      answers: {},           // { rivers: { q1: '...' } }
      hintsUsed: {},         // { rivers: 2 }
      finalTask: {},
      lastUpdated: ''
    };
  }

  function defaultSettings() {
    return {
      unlockAll: false,          // מצב מורה: כל התחנות פתוחות
      showScores: true,
      allowHints: true,
      revealAfterAttempts: 3
    };
  }

  function defaultA11y() {
    return {
      largeText: false,
      highContrast: false,
      reduceMotion: false
    };
  }

  function read(key, fallback) {
    try {
      var raw = window.localStorage.getItem(key);
      if (!raw) return fallback();
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object') return fallback();
      var base = fallback();
      for (var k in base) {
        if (Object.prototype.hasOwnProperty.call(parsed, k)) base[k] = parsed[k];
      }
      return base;
    } catch (err) {
      console.warn('[IGJ] קריאה מהאחסון נכשלה:', key, err);
      return fallback();
    }
  }

  function write(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.warn('[IGJ] שמירה לאחסון נכשלה:', key, err);
      return false;
    }
  }

  IGJ.storage = {
    available: function () {
      try {
        window.localStorage.setItem('igj.test', '1');
        window.localStorage.removeItem('igj.test');
        return true;
      } catch (err) {
        return false;
      }
    },

    /* ---------- מצב התלמיד ---------- */

    getState: function () {
      return read(STATE_KEY, emptyState);
    },

    saveState: function (state) {
      state.lastUpdated = new Date().toISOString();
      return write(STATE_KEY, state);
    },

    /** עדכון נקודתי: IGJ.storage.update(s => { s.studentName = 'דנה'; }) */
    update: function (mutator) {
      var state = IGJ.storage.getState();
      mutator(state);
      IGJ.storage.saveState(state);
      return state;
    },

    hasJourney: function () {
      var s = IGJ.storage.getState();
      return Boolean(s.studentName) || s.completedStations.length > 0 ||
             Object.keys(s.stationProgress).length > 0;
    },

    resetState: function () {
      try { window.localStorage.removeItem(STATE_KEY); } catch (err) { /* מתעלמים */ }
    },

    /* ---------- הגדרות מורה ---------- */

    getSettings: function () {
      return read(SETTINGS_KEY, defaultSettings);
    },

    saveSettings: function (settings) {
      return write(SETTINGS_KEY, settings);
    },

    resetSettings: function () {
      try { window.localStorage.removeItem(SETTINGS_KEY); } catch (err) { /* מתעלמים */ }
    },

    /* ---------- העדפות נגישות ---------- */

    getA11y: function () {
      return read(A11Y_KEY, defaultA11y);
    },

    saveA11y: function (prefs) {
      return write(A11Y_KEY, prefs);
    }
  };
})();
