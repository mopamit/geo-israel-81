/* ------------------------------------------------------------------
   progress.js — כל ההיגיון של "איפה התלמיד עומד".
   תלוי ב-storage.js וב-data/stations.js.
------------------------------------------------------------------ */
window.IGJ = window.IGJ || {};

(function () {
  'use strict';

  var PASS_MARK = 70; // רף השלמה ברירת מחדל, לפי סעיף 28 באפיון

  function indexOfStation(id) {
    for (var i = 0; i < IGJ.stations.length; i++) {
      if (IGJ.stations[i].id === id) return i;
    }
    return -1;
  }

  IGJ.progress = {
    PASS_MARK: PASS_MARK,

    /** locked | available | in-progress | completed */
    stateOf: function (stationId, state, settings) {
      state = state || IGJ.storage.getState();
      settings = settings || IGJ.storage.getSettings();

      if (state.completedStations.indexOf(stationId) !== -1) return 'completed';

      var idx = indexOfStation(stationId);
      var prev = idx > 0 ? IGJ.stations[idx - 1] : null;
      var unlocked = settings.unlockAll || !prev ||
                     state.completedStations.indexOf(prev.id) !== -1;

      if (!unlocked) return 'locked';
      return (state.stationProgress[stationId] > 0) ? 'in-progress' : 'available';
    },

    /** אחוז ההתקדמות בתוך תחנה (לפי שלבים) */
    percentOf: function (stationId, state) {
      state = state || IGJ.storage.getState();
      var station = IGJ.stationById(stationId);
      if (!station) return 0;
      if (state.completedStations.indexOf(stationId) !== -1) return 100;
      var done = state.stationProgress[stationId] || 0;
      return Math.min(100, Math.round((done / station.steps) * 100));
    },

    scoreOf: function (stationId, state) {
      state = state || IGJ.storage.getState();
      var score = state.scores[stationId];
      return (typeof score === 'number') ? score : null;
    },

    /** אחוז השלמה כולל של המסע */
    overall: function (state) {
      state = state || IGJ.storage.getState();
      var total = 0;
      IGJ.stations.forEach(function (s) {
        total += IGJ.progress.percentOf(s.id, state);
      });
      return Math.round(total / IGJ.stations.length);
    },

    /** התחנה שאליה כדאי לחזור: הראשונה שאינה מושלמת ואינה נעולה */
    nextStation: function (state, settings) {
      state = state || IGJ.storage.getState();
      settings = settings || IGJ.storage.getSettings();
      for (var i = 0; i < IGJ.stations.length; i++) {
        var st = IGJ.progress.stateOf(IGJ.stations[i].id, state, settings);
        if (st === 'in-progress' || st === 'available') return IGJ.stations[i];
      }
      return null;
    },

    /* ---------- כתיבה ---------- */

    /** שמירת התקדמות בתוך תחנה (נקרא מדף התחנה בשלב 3) */
    markStep: function (stationId, stepNumber) {
      return IGJ.storage.update(function (s) {
        var current = s.stationProgress[stationId] || 0;
        s.stationProgress[stationId] = Math.max(current, stepNumber);
        s.currentStation = stationId;
      });
    },

    completeStation: function (stationId, score) {
      return IGJ.storage.update(function (s) {
        if (s.completedStations.indexOf(stationId) === -1) {
          s.completedStations.push(stationId);
        }
        var station = IGJ.stationById(stationId);
        if (station) s.stationProgress[stationId] = station.steps;
        if (typeof score === 'number') s.scores[stationId] = score;
        s.currentStation = stationId;
      });
    },

    addHint: function (stationId) {
      return IGJ.storage.update(function (s) {
        s.hintsUsed[stationId] = (s.hintsUsed[stationId] || 0) + 1;
      });
    }
  };
})();
