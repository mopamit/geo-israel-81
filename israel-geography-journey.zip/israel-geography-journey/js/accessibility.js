/* ------------------------------------------------------------------
   accessibility.js — העדפות נגישות שנשמרות ומוחלות בכל דף.
   מוסיף מחלקות ל-<html>:  a11y-large / a11y-contrast / a11y-still
   ומייצר את חלונית הנגישות מכפתור עם  data-a11y-toggle.
------------------------------------------------------------------ */
window.IGJ = window.IGJ || {};

(function () {
  'use strict';

  var root = document.documentElement;

  function apply(prefs) {
    root.classList.toggle('a11y-large', !!prefs.largeText);
    root.classList.toggle('a11y-contrast', !!prefs.highContrast);
    root.classList.toggle('a11y-still', !!prefs.reduceMotion);
  }

  function buildPanel(prefs, onChange) {
    var panel = document.createElement('div');
    panel.className = 'a11y-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'הגדרות נגישות');
    panel.hidden = true;

    panel.innerHTML =
      '<h2 class="a11y-panel__title">נגישות</h2>' +
      '<label class="a11y-row"><input type="checkbox" data-pref="largeText"> טקסט מוגדל</label>' +
      '<label class="a11y-row"><input type="checkbox" data-pref="highContrast"> ניגודיות גבוהה</label>' +
      '<label class="a11y-row"><input type="checkbox" data-pref="reduceMotion"> הפחתת אנימציות</label>' +
      '<button type="button" class="btn btn--quiet a11y-close">סגירה</button>';

    panel.querySelectorAll('input[data-pref]').forEach(function (input) {
      var key = input.getAttribute('data-pref');
      input.checked = !!prefs[key];
      input.addEventListener('change', function () {
        prefs[key] = input.checked;
        onChange(prefs);
      });
    });

    return panel;
  }

  IGJ.accessibility = {
    init: function () {
      var prefs = IGJ.storage.getA11y();
      apply(prefs);

      var trigger = document.querySelector('[data-a11y-toggle]');
      if (!trigger) return;

      var panel = buildPanel(prefs, function (updated) {
        IGJ.storage.saveA11y(updated);
        apply(updated);
      });
      document.body.appendChild(panel);

      function close() {
        panel.hidden = true;
        trigger.setAttribute('aria-expanded', 'false');
        trigger.focus();
      }

      trigger.setAttribute('aria-expanded', 'false');
      trigger.addEventListener('click', function () {
        panel.hidden = !panel.hidden;
        trigger.setAttribute('aria-expanded', String(!panel.hidden));
        if (!panel.hidden) panel.querySelector('input').focus();
      });

      panel.querySelector('.a11y-close').addEventListener('click', close);
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && !panel.hidden) close();
      });
    }
  };
})();
