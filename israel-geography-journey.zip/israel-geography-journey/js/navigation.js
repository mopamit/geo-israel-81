/* ------------------------------------------------------------------
   navigation.js — קישורים יחסיים והודעות מערכת.
   כל דף מצהיר על השורש שלו:  <html data-root=".">  או  <html data-root="..">
------------------------------------------------------------------ */
window.IGJ = window.IGJ || {};

(function () {
  'use strict';

  var root = document.documentElement.getAttribute('data-root') || '.';

  IGJ.nav = {
    root: root,

    /** נתיב יחסי מהדף הנוכחי אל קובץ ב-Repository */
    path: function (relative) {
      return root + '/' + String(relative).replace(/^\.?\//, '');
    },

    toRoute: function () {
      window.location.href = IGJ.nav.path('pages/route.html');
    },

    toHome: function () {
      window.location.href = IGJ.nav.path('index.html');
    },

    toStation: function (station) {
      window.location.href = IGJ.nav.path('pages/' + station.page);
    },

    /** הודעה קצרה שנעלמת מעצמה, ומוכרזת גם לקורא מסך */
    toast: function (message) {
      var box = document.querySelector('.toast');
      if (!box) {
        box = document.createElement('div');
        box.className = 'toast';
        box.setAttribute('role', 'status');
        box.setAttribute('aria-live', 'polite');
        document.body.appendChild(box);
      }
      box.textContent = message;
      box.classList.add('is-visible');
      window.clearTimeout(box._timer);
      box._timer = window.setTimeout(function () {
        box.classList.remove('is-visible');
      }, 3200);
    }
  };

  /* כפתורי חזרה כלליים: <button data-nav="route"> / data-nav="home" */
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-nav]');
    if (!el) return;
    var target = el.getAttribute('data-nav');
    if (target === 'route') IGJ.nav.toRoute();
    if (target === 'home') IGJ.nav.toHome();
  });
})();
