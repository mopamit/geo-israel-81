/* ------------------------------------------------------------------
   נתוני התחנות — מטא־דאטה בלבד (ללא תוכן לימודי).
   התוכן עצמו (נחלים, ערים, אתרים...) יישב בקבצים נפרדים בתיקיית data.
   סדר המערך = סדר ההתקדמות במסלול.
   x, y = מיקום התחנה על מסך המסלול, באחוזים (מימין לשמאל).
------------------------------------------------------------------ */
window.IGJ = window.IGJ || {};

IGJ.stations = [
  {
    id: 'rivers',
    title: 'נחלי ישראל',
    subtitle: 'לאן זורמים המים',
    color: '#1F6FB2',
    page: 'rivers.html',
    steps: 6,
    minutes: 25,
    goal: 'להבין כיצד התבליט וקו פרשת המים קובעים את כיוון זרימת הנחלים, ומה ההבדל בין נחל איתן לנחל אכזב.',
    x: 10,
    y: 62
  },
  {
    id: 'capitals',
    title: 'בירות חבלי הארץ',
    subtitle: 'מה הופך עיר למרכז',
    color: '#B23A34',
    page: 'regional-capitals.html',
    steps: 5,
    minutes: 25,
    goal: 'לזהות את הערים המרכזיות בישראל ולהבין אילו שירותים הופכים עיר למרכז של חבל ארץ שלם.',
    x: 27,
    y: 30
  },
  {
    id: 'heritage',
    title: 'מרכזי מורשת',
    subtitle: 'סיפורו של מקום',
    color: '#D4922B',
    page: 'heritage.html',
    steps: 5,
    minutes: 20,
    goal: 'להבין מהו אתר מורשת, מדוע משמרים אותו, ומה הקשר בין מקום, זיכרון וזהות.',
    x: 45,
    y: 66
  },
  {
    id: 'border',
    title: 'יישובי ספר',
    subtitle: 'לחיות על הגבול',
    color: '#2E7D52',
    page: 'border-settlements.html',
    steps: 5,
    minutes: 30,
    goal: 'להכיר את יישובי הספר ולבחון את הקשר בין ביטחון, כלכלה, תחבורה וקהילה בפריפריה.',
    x: 63,
    y: 26
  },
  {
    id: 'mountains',
    title: 'הרי ישראל',
    subtitle: 'הגובה משנה הכול',
    color: '#8A5A32',
    page: 'mountains.html',
    steps: 6,
    minutes: 25,
    goal: 'להכיר את שדרת ההר המרכזית ולהבין כיצד הגובה משפיע על אקלים, מים, נוף והתיישבות.',
    x: 79,
    y: 60
  },
  {
    id: 'final',
    title: 'משימת הסיכום',
    subtitle: 'תכנון סיור לימודי',
    color: '#223046',
    page: 'final-task.html',
    steps: 4,
    minutes: 30,
    goal: 'לתכנן סיור לימודי בן יום אחד שמחבר בין כל נושאי היחידה — ולבדוק שהוא באמת אפשרי.',
    x: 91,
    y: 24,
    isFinal: true
  }
];

IGJ.stationById = function (id) {
  return IGJ.stations.filter(function (s) { return s.id === id; })[0] || null;
};
