/* ------------------------------------------------------------------
   teacher.js — מסך מורה מקומי.
------------------------------------------------------------------ */
(function () {
  'use strict';

  IGJ.accessibility.init();

  var settings = IGJ.storage.getSettings();

  /* ---------- הגדרות ---------- */
  document.querySelectorAll('[data-setting]').forEach(function (input) {
    var key = input.getAttribute('data-setting');

    if (input.type === 'checkbox') {
      input.checked = !!settings[key];
      input.addEventListener('change', function () {
        settings[key] = input.checked;
        IGJ.storage.saveSettings(settings);
        IGJ.nav.toast('ההגדרה נשמרה.');
      });
    } else {
      input.value = settings[key];
      input.addEventListener('change', function () {
        var n = parseInt(input.value, 10);
        if (isNaN(n) || n < 1) { n = 1; input.value = '1'; }
        settings[key] = n;
        IGJ.storage.saveSettings(settings);
        IGJ.nav.toast('ההגדרה נשמרה.');
      });
    }
  });

  /* ---------- מעבר ישיר לתחנה ---------- */
  var list = document.getElementById('teacherStations');
  IGJ.stations.forEach(function (station) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn teacher__station';
    btn.style.setProperty('--station-color', station.color);
    btn.textContent = station.title;
    btn.addEventListener('click', function () { IGJ.nav.toStation(station); });
    list.appendChild(btn);
  });

  /* ---------- מצב התלמיד ---------- */
  function renderState() {
    var state = IGJ.storage.getState();
    var box = document.getElementById('teacherState');

    if (!IGJ.storage.hasJourney()) {
      box.innerHTML = '<p class="home__note">אין עדיין התקדמות שמורה במכשיר הזה.</p>';
      return;
    }

    var rows = IGJ.stations.map(function (s) {
      var status = IGJ.progress.stateOf(s.id, state, settings);
      var percent = IGJ.progress.percentOf(s.id, state);
      var score = IGJ.progress.scoreOf(s.id, state);
      var hints = state.hintsUsed[s.id] || 0;
      return '<tr>' +
        '<th scope="row">' + s.title + '</th>' +
        '<td>' + percent + '%</td>' +
        '<td>' + (score === null ? '—' : score + '%') + '</td>' +
        '<td>' + hints + '</td>' +
      '</tr>';
    }).join('');

    box.innerHTML =
      '<p class="home__note">תלמיד: <strong>' + (state.studentName || 'ללא שם') + '</strong></p>' +
      '<table class="teacher__table">' +
        '<thead><tr><th scope="col">תחנה</th><th scope="col">התקדמות</th>' +
        '<th scope="col">ציון</th><th scope="col">רמזים</th></tr></thead>' +
        '<tbody>' + rows + '</tbody>' +
      '</table>';
  }

  document.getElementById('resetStateBtn').addEventListener('click', function () {
    if (!window.confirm('לאפס את התקדמות התלמיד במכשיר הזה?')) return;
    IGJ.storage.resetState();
    renderState();
    IGJ.nav.toast('ההתקדמות אופסה.');
  });

  document.getElementById('resetSettingsBtn').addEventListener('click', function () {
    IGJ.storage.resetSettings();
    window.location.reload();
  });

  renderState();
})();
